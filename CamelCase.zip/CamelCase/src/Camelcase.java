import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Camelcase {
    public static void main(String[] args) {

        // on met les chemins des fichiers d'entrée et sortie
        String fichierEntree = "../CamelCase/inputText.txt";
        String fichierSortie = "../CamelCase/outputText.txt";

        try {
            // création des fonctions d'écriture et de lecture pour les fichiers d'entrée et de sortie
            BufferedReader lecteur = new BufferedReader(new FileReader(fichierEntree));
            BufferedWriter redacteur = new BufferedWriter(new FileWriter(fichierSortie));

            String ligne;
            // boucle while permettant la lecture de chaque ligne, puis la conversion et enfin l'écriture dans le fichier de sortie
            while ((ligne = lecteur.readLine()) != null) {
                String ligneConvertie = convertirPhrase(ligne);
                redacteur.write(ligne + " -> " + ligneConvertie);
                redacteur.newLine();
            }

            // Fermeture des fonctions d'écriture et de lecture
            lecteur.close();
            redacteur.close();
            // Affichage des messages de confirmation si c'est bon et d'erreur si ce n'est pas bon
            System.out.println("Conversion terminée. Les résultats sont enregistrés dans " + fichierSortie);
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture ou de l'écriture du fichier : " + e.getMessage());
        }
    }

    private static String convertirPhrase(String phrase) {
        String[] mots = phrase.split(" "); // Division de la phrase en mots en utilisant un espace comme séparateur
        StringBuilder resultat = new StringBuilder(); // StringBuilder pour stocker le résultat de la conversion

        for (String mot : mots) { // Parcours de chaque mot dans la phrase
            resultat.append(convertirMot(mot)); // Conversion du mot en camelCase et ajout au constructeur de phrase
        }

        return resultat.toString(); // Conversion du StringBuilder en chaîne de caractères et retour du résultat
    }

    private static String convertirMot(String mot) {
        StringBuilder converti = new StringBuilder(); // constructeur de phrase pour stocker le mot converti en camelCase

        for (int i = 0; i < mot.length(); i++) { // On parcourt chaque caractère du mot
            char c = mot.charAt(i);

            if (Character.isLetter(c)) { // Vérification si le caractère est une lettre
                if (i == 0) { // Si c'est le premier caractère du mot
                    converti.append(Character.toUpperCase(c)); // Conversion en majuscule et ajout au StringBuilder
                } else {
                    converti.append(Character.toLowerCase(c)); // Conversion en minuscule et ajout au StringBuilder
                }
            }
        }

        return converti.toString(); // Conversion du constructeur de phrase en chaîne de caractères et retour du mot converti
    }
}
